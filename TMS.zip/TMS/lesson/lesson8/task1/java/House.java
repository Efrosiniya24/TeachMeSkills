public class House extends Build{
    public House(String type) {
        super(type);
    }


}
