public class Build {
    private String type;

    public Build(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
