public class Dantist extends Doctor{
    @Override
    public void treat() {
        System.out.println("Пройдите лечение у дантиста");
    }
}
