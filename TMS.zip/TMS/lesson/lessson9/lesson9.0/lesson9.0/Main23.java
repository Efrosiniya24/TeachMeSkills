public class Main23 {
    public static void main(String[] args) {
//        Задача 2:
//        Создать класс Person. Написать статическое финальное поле name и статический метод,
//        который выводит его имя в консоль. Реализовать в методе main другого класса вызов
//        поля и метода не создавая объекта класса Person.


        Person1.PrintName();

        System.out.println(Person1.name);
    }
}
