public abstract class Doctor {
    public abstract void treat();
}
