public class Worker implements Post{
    @Override
    public void printPost(){
        System.out.println("Рабочий");
    }
}
