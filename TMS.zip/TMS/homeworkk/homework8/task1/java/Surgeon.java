public class Surgeon extends Doctor{

    @Override
    public void treat() {
        System.out.println("Пройдите лечение у хирурга");
    }


}
