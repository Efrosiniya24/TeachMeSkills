//public class Hp extends Computer{
//    @Override
//    public  void getClassName() {
//        System.out.println("I’m HP");
//    }
//}
