public interface Post {
    void printPost();
}
