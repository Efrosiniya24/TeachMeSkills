//public class Calculator2 {
//
//    public void main(){
//        Calculator calculator2 = new Calculator(56, 72.5, "blue");
//        System.out.println("\nВес: "+ calculator2.getWeight() + "\nСтоимость: "+ calculator2.getCost() + "\nЦвет: "+ calculator2.getColor());
//    }
//}
