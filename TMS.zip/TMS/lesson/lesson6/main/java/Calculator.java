//import java.util.Scanner;
//
//public class Calculator {
//    private double weight;
//    private double cost;
//    private String color;
//
//    static Scanner scanner = new Scanner(System.in);
//
//    public Calculator(double weight, double cost, String color) {
//        this.weight = weight;
//        this.cost = cost;
//        this.color = color;
//    }
//
//    public Calculator() {
//        this.weight = 34;
//        this.cost = 76.3;
//        this.color = "yellow";
//    }
//
//    public double getWeight() {
//        return weight;
//    }
//
//    public double getCost() {
//        return cost;
//    }
//
//    public String getColor() {
//        return color;
//    }
//
//    public double sum(double a, double b){
//        return a+ b;
//    }
//
//    public double razn (double a, double b){
//        return a- b;
//    }
//
//    public double sub (double a, double b){
//        return a*b;
//    }
//
//    public double del (double a, double b){
//        return a/b;
//    }
////    public double getWeight(){
////        System.out.print("Введите вес: ");
////        this.weight = scanner.nextDouble();
////        return weight;
////    }
////
////    public double getCost(){
////        System.out.print("Введите стоимость: ");
////        scanner.next();
////        cost = scanner.nextDouble();
////        return cost;
////    }
////
////    public String getColor(){
////        System.out.print("Введите цвет: ");
////
////        color = scanner.nextLine();
////        return this.color;
////    }
//}
