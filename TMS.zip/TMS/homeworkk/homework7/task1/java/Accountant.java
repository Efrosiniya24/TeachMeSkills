public class Accountant implements Post {
    @Override
    public void printPost(){
        System.out.println("Бухгалтер");
    }
}
