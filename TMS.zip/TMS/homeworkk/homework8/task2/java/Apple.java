import java.util.Scanner;

public class Apple {
    private String color = "red";

    public Apple(String color) {
        this.color = color;
    }

    public Apple() {
    }

    public String getColor() {
        return color;
    }
}
