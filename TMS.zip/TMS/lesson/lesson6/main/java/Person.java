//import org.w3c.dom.ls.LSOutput;
//
//import java.sql.SQLOutput;
//
//public class Person {
//    private String fullName = "Woman";
//    private int age = 21;
//
//   public void talk(String text){
//       System.out.println(fullName +" talk "+ text);
//   }
//
//    public void move(){
//        System.out.println(fullName + " walk");
//    }
//
//    public Person(String fullName) {
//        this.fullName = fullName;
//    }
//
//    public Person(){
//
//    }
//
//    public Person(String fullName, int age) {
//        this.fullName = fullName;
//        this.age = age;
//    }
//}
