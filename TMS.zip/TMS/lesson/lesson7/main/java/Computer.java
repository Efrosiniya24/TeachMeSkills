//public abstract class Computer {
//     public abstract void getClassName();
//}
