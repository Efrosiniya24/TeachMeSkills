//public class Mac extends Computer{
//    @Override
//    public void getClassName() {
//        System.out.println("I’m Mac");
//    }
//}
