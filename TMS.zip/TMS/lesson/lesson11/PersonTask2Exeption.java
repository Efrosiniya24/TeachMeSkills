package lesson11;

public class PersonTask2Exeption extends Exception{
    public PersonTask2Exeption(){
        System.out.println("Ваш возраст меньше 18 лет(");
    }
}
