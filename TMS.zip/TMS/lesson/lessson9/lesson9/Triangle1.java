public class Triangle1 extends Shape {
    @Override
    public void draw(){
        System.out.println("I draw Triangle");

    }

    @Override
    public void erase(){
        System.out.println("I erase Triangle");
    }
}
