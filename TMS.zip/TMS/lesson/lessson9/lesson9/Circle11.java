public class Circle11 extends Shape{
@Override
    public void draw(){
    System.out.println("I draw Circle" );
    }
    @Override
    public void erase(){
        System.out.println("I erase Circle");
    }
}
