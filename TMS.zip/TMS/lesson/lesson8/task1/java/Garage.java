public class Garage extends Build{

   public Garage(String type){
       super(type);
   }
}
