//public interface Voice {
//    void doVoice();
//}
