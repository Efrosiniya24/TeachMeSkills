//public class Cat implements Voice{
//    @Override
//    public void doVoice(){
//        System.out.println("Мяу");
//        }
//
//}
