public class Director implements Post{
    @Override
    public void printPost(){
        System.out.println("Директор");
    }
}
