package lesson12;
import java.util.Comparator;
public class Studentsss implements Comparator<Task4Student> {
    @Override
    public int compare(Task4Student o1, Task4Student o2) {
        return 0;
    }
}
