public class Shape {

    public void draw(){
    }
    public void erase(){
    }
}
