public class Square extends Shape{
    @Override
    public void draw(){
        System.out.println("I draw Square");
    }

    @Override
    public void erase(){
        System.out.println("I erase Square");
    }
}
