public class Person1 {
    static final  String name = "Frosya";

    static void PrintName(){
        System.out.println(name);
    }
}
